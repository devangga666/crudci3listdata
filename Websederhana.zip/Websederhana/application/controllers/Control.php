<?php
    class Control extends CI_Controller{
        function __construct()
        {
            parent::__construct();
            $this->load->model('M_data');            
        }
        function index(){
            $data['tutor'] = $this->M_data->tampil_data()->result();
            $this->load->view('Home');
            $this->load->helper('url');
        }
        function tentang(){
            $data['tutor'] = $this->M_data->tentang()->result();
            $this->load->view('Tentang');
            $this->load->helper('url');
        }   

                    //Control Untuk RPL
            function rpl(){
                $data['tutor'] = $this->M_data->tampil()->result();
                $this->load->view('V_tampil',$data);
                $this->load->helper('url');
            }
            function tambah(){
                $this->load->view('V_input');
            }
            function tambah_aksi(){
                $nama = $this->input->post('nama');
                $kelas = $this->input->post('kelas');
                $jurusan = $this->input->post('jurusan');

                $data = array (
                    'nama' => $nama,
                    'kelas' => $kelas,
                    'jurusan' => $jurusan
                );
                $this->M_data->input_data($data,'tutor');
                redirect('Control/rpl');
            }

            function hapus($id){
                $where = array (
                    'id' => $id
                );
                $this->M_data->hapus_data($where,'tutor');
                redirect('Control/rpl');
            }
            function edit($id){
                $where = array('id' => $id);
                $data['tutor'] = $this->M_data->edit_data($where,'tutor')->result();
                $this->load->view('V_edit',$data);
            }
            function update(){
                $id = $this->input->post('id');
                $nama = $this->input->post('nama');
                $kelas = $this->input->post('kelas');
                $jurusan = $this->input->post('jurusan');
    
                $where = array(
                    'id' => $id
                );
                $data = array(
                    'nama' => $nama,
                    'kelas' => $kelas,
                    'jurusan' => $jurusan
                );
                $this->M_data->update_data($where,'tutor',$data);
                redirect ('Control/rpl');
            }

                        //Control untuk Perkes


            function perkes(){
                $data3['perkes'] = $this->M_data->perkes_tampil()->result();
                $this->load->view('V_perkes',$data3);
                $this->load->helper('url');
            }
            function edit_perkes($idperkes){
                $where = array('idperkes' => $idperkes);
                $data3['perkes'] = $this->M_data->perkes_edit($where,'perkes')->result();
                $this->load->view('E_perkes',$data3);
            }
            function update_p(){
                $idperkes = $this->input->post('idperkes');
                $namaa = $this->input->post('namaa');
                $kelass = $this->input->post('kelass');
                $jurusann = $this->input->post('jurusann');

                $where = array (
                    'idperkes' => $idperkes
                );
                $data3 = array(
                    'namaa' => $namaa,
                    'kelass' => $kelass,
                    'jurusann' => $jurusann
                );
                $this->M_data->update_perkes($where,'perkes',$data3);
                redirect('Control/perkes');
            }
            function tambah_perkes(){
                $this->load->view('I_perkes');
            }
            function aksi_perkes(){
                $namaa = $this->input->post('namaa');
                $kelass = $this->input->post('kelass');
                $jurusann = $this->input->post('jurusann');

                $data3 = array (
                    'namaa' => $namaa,
                    'kelass' => $kelass,
                    'jurusann' => $jurusann
                );
                $this->M_data->input_perkes($data3,'perkes');
                redirect('Control/perkes');
            }
            function hapus_p($idperkes){
                $where = array(
                    'idperkes' => $idperkes
                );
                $this->M_data->hapus_perkes($where,'perkes');
                redirect('Control/perkes');
            }
                    //Control Untuk TKJ

            function tampil_tkj(){
                $data1['tkj'] = $this->M_data->tkj_tampil()->result();
                $this->load->view('V_tkj',$data1);
                $this->load->helper('url');
            }
            function ganti($idid){
                $where = array('idid' => $idid);
                $data1['tkj'] = $this->M_data->ganti_data($where,'tkj')->result();
                $this->load->view('Edit_tkj',$data1);
            }
            function ubah(){
                $idid = $this->input->post('idid');
                $idnama = $this->input->post('idnama');
                $idkelas = $this->input->post('idkelas');
                $idjurusan = $this->input->post('idjurusan');

                $where = array (
                    'idid' => $idid
                );
                $data1 = array(
                    'idnama' => $idnama,
                    'idkelas' => $idkelas,
                    'idjurusan' => $idjurusan
                );
                $this->M_data->ubah_data($where,'tkj',$data1);
                redirect ('Control/tampil_tkj');
            }
            function hapuss($idid){
                $where = array (
                    'idid' => $idid
                );
                $this->M_data->hapus_tkj($where,'tkj');
                redirect('Control/tampil_tkj');
            }
            function tambah_tkj(){
                $this->load->view('I_tkj');
            }
            function tkj_aksi(){
                $idnama = $this->input->post('idnama');
                $idkelas = $this->input->post('idkelas');
                $idjurusan = $this->input->post('idjurusan');

                $data1 = array(
                    'idnama' => $idnama,
                    'idkelas' => $idkelas,
                    'idjurusan' => $idjurusan
                );
                $this->M_data->input_tkj($data1,'tkj');
                redirect('Control/tampil_tkj');
            }
                    //Control Untuk Farmasi
            function farmasi(){
                $data2['farmasi'] = $this->M_data->farmasi_tampil()->result();
                $this->load->view('V_farmasi',$data2);
                $this->load->helper('url');
            }
            function tambah_farmasi(){
                $this->load->view('I_farmasi');
            }
            function aksi_farmasi(){
                $namaid = $this->input->post('namaid');
                $kelasid = $this->input->post('kelasid');
                $jurusanid = $this->input->post('jurusanid');

                $data2 = array (
                    'namaid' => $namaid,
                    'kelasid' => $kelasid,
                    'jurusanid' => $jurusanid
                );
                $this->M_data->input_farmasi($data2,'farmasi');
                redirect('Control/farmasi');
            }
            function edit_farmasi($idd){
                $where = array('idd' => $idd);
                $data2['farmasi'] = $this->M_data->farmasi_edit($where,'farmasi')->result();
                $this->load->view('E_farmasi',$data2);
            }
            function atur(){
                $idd = $this->input->post('idd');
                $namaid = $this->input->post('namaid');
                $kelasid = $this->input->post('kelasid');
                $jurusanid = $this->input->post('jurusanid');

                $where = array (
                    'idd' => $idd
                );
                $data2 = array(
                    'namaid' => $namaid,
                    'kelasid' => $kelasid,
                    'jurusanid' => $jurusanid
                );
                $this->M_data->update_farmasi($where,'farmasi',$data2);
                redirect('Control/farmasi');
            }
            function hapusss($idd){
                $where = array (
                    'idd' => $idd
                );
                $this->M_data->hapus_farmasi($where,'farmasi');
                redirect('Control/farmasi');
            }
            //Control Untuk Ankim
            function ankim(){
                $data4['ankim'] = $this->M_data->ankim_tampil()->result();
                $this->load->view('V_ankim',$data4);
                $this->load->helper('url');
            }
            function tambah_ankim(){
                $this->load->view('I_ankim');
            }
            function aksi_ankim(){
                $namaankim = $this->input->post('namaankim');
                $kelasankim = $this->input->post('kelasankim');
                $jurusanankim = $this->input->post('jurusanankim');

                $data4 = array (
                    'namaankim' => $namaankim,
                    'kelasankim' => $kelasankim,
                    'jurusanankim' => $jurusanankim
                );
                $this->M_data->input_ankim($data4,'ankim');
                redirect('Control/ankim');
            }
            function edit_ankim($idankim){
                $where = array('idankim' => $idankim);
                $data4['ankim'] = $this->M_data->ankim_edit($where,'ankim')->result();
                $this->load->view('E_ankim',$data4);
            }
            function update_ankim(){
                $idankim = $this->input->post('idankim');
                $namaankim = $this->input->post('namaankim');
                $kelasankim = $this->input->post('kelasankim');
                $jurusanankim = $this->input->post('jurusanankim');

                $where = array (
                    'idankim' => $idankim
                );
                $data4 = array(
                    'namaankim' => $namaankim,
                    'kelasankim' => $kelasankim,
                    'jurusanankim' => $jurusanankim
                );
                $this->M_data->ankim_update($where,'ankim',$data4);
                redirect('Control/ankim');
            }
            function ankim_hapus($idankim){
                $where = array (
                    'idankim' => $idankim
                );
                $this->M_data->hapus_ankim($where,'ankim');
                redirect('Control/ankim');
            }

        }