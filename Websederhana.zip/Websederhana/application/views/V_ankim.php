<!DOCTYPE html>
<head>
<title>List data Siswa</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
  body {
    background-image:url(https://scontent.fcgk9-2.fna.fbcdn.net/v/t31.0-8/16700597_388972374810824_1801649612069272450_o.jpg?_nc_cat=101&ccb=3&_nc_sid=6e5ad9&_nc_eui2=AeFMIr_J5Rc-rjrFjsTdUrhrbjjTbIKBwppuONNsgoHCmhXU5lwinniZl3dK6SWia9cnkjtJTZojGXBuAwEvdWY1&_nc_ohc=5-m0widiJo0AX_kcLnZ&_nc_ht=scontent.fcgk9-2.fna&oh=914c6c19f5f42d3262f3ce8ccdc6d36a&oe=60615D04);
    background-repeat:no-repeat;
    background-size:cover;  
    }
  h1{
    color:white;
  }
  .stroke {
      font-size: 40px;
      color: #fff;
      font-weight: bolder;
      -webkit-text-stroke: 0.02em #000;
   }
   
</style>
</head>
</body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url('Control/index'); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="<?= base_url('Control/tentang'); ?>">Tentang Website</a>
      </li>
    </ul>
  </div>
</nav>
</br>
<center><h1 class="stroke"><div class="card-body">
    <b>List Data Siswa SMK Farmako Medika Plus Jurusan RPL</b>
  </div></h1></center>
<div class="container">
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-pills card-header-pills">
      <li class="nav-item">
      <span><a href="<?= base_url('Control/tambah_ankim'); ?>" class="btn btn-primary">Tambah Data</a></span>
      </li>
    </ul>
  </div>
  <div class="card-body">
  </div>
  <table class="table table-bordered table-stripped">
    <thead>
    <tr>
    <th>ID</th>
    <th>Nama</th>
    <th>Kelas</th>
    <th>Jurusan</th>
    <th>Aksi</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $no=1;
    foreach ($ankim as $a){
        ?>
    <tr>
    <td><?php echo $no++ ?></td>
    <td><?php echo $a->namaankim ?></td>
    <td><?php echo $a->kelasankim ?></td>
    <td><?php echo $a->jurusanankim ?></td>
    <td>
    <a class="btn btn-warning" href="<?= base_url('Control/edit_ankim/'.$a->idankim);?>">Edit</a>
    <a class="btn btn-danger" href="<?= base_url('Control/ankim_hapus/'.$a->idankim);?>">Hapus</a>
    </td>
    </tr>
    <?php } ?>
    </tbody>
    </table>
  </div>

</body>
</html>